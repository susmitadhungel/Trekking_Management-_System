<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS  | Package List</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet">
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="banner-3">
	<div class="container"></div>
</div>
<div class="rooms">
	<div class="container">
		<div class="room-bottom">
			<h3>Package List</h3>

<?php
// Include database connection
include('includes/config.php');

// Get the search term from the form
$search = isset($_GET['destination']) ? strtolower(trim($_GET['destination'])) : '';

// Query to fetch all packages and sort them by PackageName
$sql = "SELECT * FROM tbltourpackages ORDER BY PackageName ASC";
$query = $dbh->prepare($sql);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);

// Binary Search Function
function binarySearch($packages, $searchTerm) {
    $low = 0;
    $high = count($packages) - 1;
    $matches = [];

    while ($low <= $high) {
        $mid = floor(($low + $high) / 2);
        $currentName = strtolower($packages[$mid]->PackageName);

        if (strpos($currentName, $searchTerm) !== false) {
            // Match found, collect it
            $matches[] = $packages[$mid];

            // Check adjacent elements for additional matches
            $left = $mid - 1;
            $right = $mid + 1;

            while ($left >= 0 && strpos(strtolower($packages[$left]->PackageName), $searchTerm) !== false) {
                $matches[] = $packages[$left--];
            }
            while ($right < count($packages) && strpos(strtolower($packages[$right]->PackageName), $searchTerm) !== false) {
                $matches[] = $packages[$right++];
            }
            break; // Exit after collecting matches
        }

        if ($currentName < $searchTerm) {
            $low = $mid + 1;
        } else {
            $high = $mid - 1;
        }
    }

    return $matches;
}

// Perform Binary Search
$matchedResults = $search ? binarySearch($results, $search) : $results;
?>

<h1>Search Results for "<?php echo htmlspecialchars($search); ?>"</h1>

<?php
if (!empty($matchedResults)) {
    foreach ($matchedResults as $result) {
        ?>
        <div class="rom-btm">
				<div class="col-md-3 room-left wow fadeInLeft animated" data-wow-delay=".5s">
					<img src="admin/pacakgeimages/<?php echo htmlentities($result->PackageImage); ?>" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 room-midle wow fadeInUp animated" data-wow-delay=".5s">
					<h4>Package Name: <?php echo htmlentities($result->PackageName); ?></h4>
					<h6>Package Type : <?php echo htmlentities($result->PackageType); ?></h6>
					<p><b>Package Location :</b> <?php echo htmlentities($result->PackageLocation); ?></p>
					<p><b>Features</b> <?php echo htmlentities($result->PackageFetures); ?></p>
				</div>
				<div class="col-md-3 room-right wow fadeInRight animated" data-wow-delay=".5s">
					<h5>RS <?php echo htmlentities($result->PackagePrice); ?></h5>
					<a href="package-details.php?pkgid=<?php echo htmlentities($result->PackageId); ?>" class="view">Details</a>
				</div>
				<div class="clearfix"></div>
			</div>
        <?php
    }
} else {
    echo "<p>No matching destinations found.</p>";
}
?>

</body>
</html>
